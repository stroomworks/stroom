# Shapeshifter AI demo

One Shapeshifter AI document, four feeds of four unrelated formats, a pipeline for each,
and nothing telling any of them what its format is. Import this pack, give it a model and
post some data.

Import it from **Tools -> Import**, or drop the zip into the `content_pack_import`
directory of an instance with `stroom.contentPackImport.enabled` set.

## What is in it

- **`Any feed`** — the supervised stage's configuration: what it may learn with, how
  candidates are scored, and when one is promoted.
- **`Learning model`** — the model the stage asks. Edit it before running anything.
- **`<feed> supervised`** — a pipeline for each feed, `Source -> Shapeshifter AI -> Schema
  filter -> ... -> Stream appender`, each learning its own feed (one pipeline per feed, as
  the Pipeline Factory makes them).
- **`DOOR-ACCESS`, `APP-EVENTS`, `FIREWALL`, `MAINFRAME`** — four feeds. The pack tells the stages nothing about their formats.

A processor filter over each feed comes with its pipeline. Importing from
**Tools -> Import** leaves it switched off unless you tick **Enable Processor Filters**
on the confirmation screen; a pack dropped in `content_pack_import` arrives with it on.
Set the model up before posting anything, or the first stream will fail for want of an
API key.

## Before you run it

1. Open `Learning model` and set the base URL and model id for an OpenAI-compatible endpoint.
2. Create a stored secret named `shapeshifter-ai` holding that endpoint's API key. The pack carries
   the name of the secret and never the key itself.
3. Make sure the event-logging XML schemas are installed, since the stage gates every
   candidate on validating against the `EVENTS` schema group.

## Running it

Post a file to any of the four feeds as `Raw Events`. There is one under `data/` for
each of them, and nothing stops you posting your own:

| Feed | Sample | What it is |
|---|---|---|
| `DOOR-ACCESS` | `data/door-access.csv` | Delimited text with a header row. |
| `APP-EVENTS` | `data/app-events.jsonl` | JSON, one object per line. |
| `FIREWALL` | `data/firewall.log` | Syslog, in two forms from two senders. |
| `MAINFRAME` | `data/mainframe.log` | Fixed-width columns with nothing to split on. |

The feed's pipeline will find nothing learned yet, ask the model which parser the format
needs, learn a configuration for it, score what comes back and — if it clears the floor —
bind it and translate the stream with what it just learned. The feed's next stream is
served by that binding without the model being asked again.

Watch it happen in the **Supervisor**: the attempts, what each question was and what came
back, the scores each candidate got and why a candidate was refused, and what is serving
each pipeline.

## What the settings mean

The interesting ones are on the document's own tabs, and all of them can be changed:

- **Allowed elements** is every parser the stage knows how to configure. Narrowing it is
  how you would tell the stage what a feed is; the demo deliberately does not.
- **The flow** is the escalating one: ask directly first, and only propose a target event
  when the transform falls short. It is a graph of steps and you can edit it.
- **The scorers** gate on compiling, on the output validating against the schema, and on
  the extraction being worth having — the last of these is what refuses a transform that
  validates while saying nothing.
- **Promotion floor** is the score a candidate must reach before its binding goes live.

## The formats it was proved on

Design 02 §5 scenario 51 runs exactly these settings over delimited text with a header,
JSON lines, syslog in two forms, and fixed-width columns with nothing to split on. The
sample data under `data/` in this pack is that scenario's, one file per feed.
